package com.edgar.core.spring;

/**
 * Created by edgar on 15-6-14.
 */
public interface ServiceLookup {
    <T> T getBean(String beanName, Class<T> clazz);

    <T> T getBean(Class<T> clazz);

    <T> T getBean(String name);
}
