package com.edgar.core.service.impl;

import com.edgar.core.service.Pagination;
import com.edgar.core.service.PaginationCmd;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
public class PaginationServiceImpl implements com.edgar.core.service.PaginationService {

    private static final String OFFSET = "offset";
    private static final String LIMIT = "limit";
    private static final int MAX_RECORDS = 10000;

    @Autowired
    private SqlSession session;

    /**
     * 直接计算总数
     *
     * @param command
     * @param <T>
     * @return
     */
    @Override
    public <T> Pagination<T> fetchPage(PaginationCmd<T> command) {
        Map<String, Object> params = Maps.newHashMap(command.getParams());
        params.put(OFFSET, 0);
        params.put(LIMIT, MAX_RECORDS);
        //查询总数
        final int totalRecords = session.selectOne(command.getCountStmt(), Collections.unmodifiableMap(params));
        if (totalRecords == 0) {
            return Pagination.newInstance(command.getPage(), command.getPageSize(), totalRecords, Lists.newArrayList());
        }
        //计算页面
        int pageSize = command.getPageSize();
        int page = command.getPage();
        int pageCount = totalRecords / pageSize;
        if (totalRecords > pageSize * pageCount) {
            pageCount++;
        }
        if (pageCount < page) {
            page = pageCount;
        }
        int offset = (page - 1) * pageSize;
        params.put(OFFSET, offset);
        params.put(LIMIT, pageSize);
        List<T> records = session.selectList(command.getSelectStmt(), Collections.unmodifiableMap(params));
        return Pagination.newInstance(page, pageSize, totalRecords, records);
    }
}  