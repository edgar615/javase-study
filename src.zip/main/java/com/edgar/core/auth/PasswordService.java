package com.edgar.core.auth;

import com.edgar.domain.User;

public interface PasswordService {
    String encryptPassword(String username, String password, String salt);

    String saltGenerator();

    String randomPassword();
}