package com.edgar.app.service.impl;

import com.edgar.app.service.ApplicantService;
import com.edgar.core.repository.BaseMapper;
import com.edgar.core.repository.IDSeq;
import com.edgar.core.service.Pagination;
import com.edgar.core.service.PaginationCmd;
import com.edgar.core.service.PaginationCmdBuilder;
import com.edgar.core.service.PaginationService;
import com.edgar.core.service.impl.BaseServiceImpl;
import com.edgar.domain.Applicant;
import com.edgar.repository.ApplicantMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by edgar on 15-6-15.
 */
@Service
public class ApplicantServiceImpl extends BaseServiceImpl<Applicant, Integer> implements ApplicantService {

    @Autowired
    private ApplicantMapper applicantMapper;

    @Autowired
    private PaginationService paginationService;

    @Autowired
    private IDSeq idSeq;

    @Override
    public BaseMapper<Applicant, Integer> getMapper() {
        return applicantMapper;
    }

    @Override
    public int insert(Applicant entity) {
        if (entity.getId() == null || entity.getId() > 0) {
            entity.setId(idSeq.nextId());
        }
        return super.insert(entity);
    }

    @Override
    public Applicant fetchApplicantByUserId(int userId) {
        return applicantMapper.selectByUserId(userId);
    }

    @Override
    public Pagination<Applicant> pagination(Map<String, Object> params, int page, int pageSize) {
        PaginationCmd<Applicant> command = new PaginationCmdBuilder()
                .setParams(params)
                .setPage(page)
                .setPageSize(pageSize)
                .setCountStmt("com.edgar.repository.ApplicantMapper.count")
                .setSelectStmt("com.edgar.repository.ApplicantMapper.query").builder();
        return paginationService.fetchPage(command);
    }
}
