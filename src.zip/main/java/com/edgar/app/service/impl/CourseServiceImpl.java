package com.edgar.app.service.impl;

import com.edgar.app.service.CourseService;
import com.edgar.core.repository.BaseMapper;
import com.edgar.core.repository.IDSeq;
import com.edgar.core.service.Pagination;
import com.edgar.core.service.PaginationCmd;
import com.edgar.core.service.PaginationCmdBuilder;
import com.edgar.core.service.PaginationService;
import com.edgar.core.service.impl.BaseServiceImpl;
import com.edgar.domain.Course;
import com.edgar.domain.CourseSum;
import com.edgar.repository.CourseMapper;
import com.edgar.repository.CourseSumMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by edgar on 15-6-11.
 */
@Service
public class CourseServiceImpl extends BaseServiceImpl<Course, Integer> implements CourseService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CourseServiceImpl.class);

    @Autowired
    private CourseMapper courseMapper;

    @Autowired
    private CourseSumMapper courseSumMapper;

    @Autowired
    private PaginationService paginationService;

    @Autowired
    private IDSeq idSeq;

    @Override
    public BaseMapper<Course, Integer> getMapper() {
        return courseMapper;
    }

    @Override
    public int insert(Course entity) {
        int result = super.insert(entity);
        //更新courseSum
        CourseSum courseSum = courseSumMapper.fetchByType(entity.getOccupation(), entity.getApplicationLevel());
        courseSum.setCourseSumId(idSeq.nextId());
        courseSum.setApplicationLevel(entity.getApplicationLevel());
        courseSum.setOccupation(entity.getApplicationLevel());
        courseSum.setCourseTime(entity.getCourseTime());
        courseSumMapper.insert(courseSum);
//        if (courseSum == null) {
//            try {
//
//            } catch (Exception e) {
//
//            }
//        }

        return result;
    }

    @Override
    public Pagination<Course> pagination(Map<String, Object> params, int page, int pageSize) {
        PaginationCmd<Course> command = new PaginationCmdBuilder()
                .setParams(params)
                .setPage(page)
                .setPageSize(pageSize)
                .setCountStmt("com.edgar.repository.CourseMapper.count")
                .setSelectStmt("com.edgar.repository.CourseMapper.query").builder();
        return paginationService.fetchPage(command);
    }
}
