package com.edgar.app.service.impl;

import com.edgar.app.service.CourseService;
import com.edgar.app.service.IndexService;
import javafx.scene.control.Pagination;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by edgar on 15-6-11.
 */
public class IndexServiceImpl implements IndexService {

    @Autowired
    private CourseService courseService;

    @Override
    public Pagination pagination(int page, int pageSize) {
        return null;
//        return courseService.pagination(page, pageSize);
    }
}
