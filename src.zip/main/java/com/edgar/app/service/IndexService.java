package com.edgar.app.service;

import javafx.scene.control.Pagination;

/**
 * Created by edgar on 15-6-11.
 */
public interface IndexService {

    Pagination pagination(int page, int pageSize);
}
