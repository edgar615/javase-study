/* Navigation Menu */

ddlevelsmenu.setup("ddtopmenubar", "topbar");

/* Scroll to Top */

$(".totop").hide();

$(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.totop').slideDown();
        }
        else {
            $('.totop').slideUp();
        }
    });

    $('.totop a').click(function (e) {
        e.preventDefault();
        $('body,html').animate({scrollTop: 0}, 500);
    });
    //查询
    $("#query-btn").click(function() {
        goto(1);
    })
    queryForm();

});

function queryForm() {
    var formMinus = "form-minus";
    var form = $("#query-form");
    if (form.hasClass(formMinus)) {
        form.find('.title').prepend('<i class="icon-angle-right"></i><label class="blank5">&nbsp;</label>');
    } else {
        form.find('.title').prepend('<i class="icon-angle-down"></i><label class="blank5">&nbsp;</label>');
    }

    form.find('.title').click(function () {
        if (form.hasClass(formMinus)) {
            form.find('.title').find('i').removeClass("icon-angle-right").addClass("icon-angle-down");
            form.removeClass("form-minus");
        } else {
            form.find('.title').find('i').removeClass("icon-angle-down").addClass("icon-angle-right");
            form.addClass("form-minus");
        }
    });
}

function goto(pageIndex) {
    $("#query-form input[name=_q_page]").val(pageIndex);
    $("#query-form input, #query-form select").each(function(i, v) {
        if ($(v).val() == "") {
            $(v).attr("disabled", "disabled");
        }
    });
    $("#query-form").submit();
}
