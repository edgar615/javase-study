package com.edgar.core.command;

/**
 * Created by edgar on 15-6-11.
 */
public class TestCommand implements Command {
}
