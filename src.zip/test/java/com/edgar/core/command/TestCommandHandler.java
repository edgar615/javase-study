package com.edgar.core.command;

import org.springframework.stereotype.Service;

@Service
public class TestCommandHandler implements CommandHandler<TestCommand> {
    @Override
    public CommandResult<?> execute(TestCommand command) {
        return CommandResult.newInstance(1);
    }
}
