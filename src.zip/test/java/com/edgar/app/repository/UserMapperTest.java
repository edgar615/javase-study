package com.edgar.app.repository;

import com.edgar.domain.User;
import com.edgar.repository.UserMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/dao.xml"})
@TransactionConfiguration(defaultRollback = true)
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        TransactionalTestExecutionListener.class})
public class UserMapperTest {

    @Autowired
    private UserMapper userMapper;

    @Test
    public void testFetchByUsername() {
        String username = "admin";
        User user = userMapper.fetchByUsername(username);
        Assert.assertNotNull(user);

        username = "admin1";
        user = userMapper.fetchByUsername(username);
        Assert.assertNull(user);

    }

}
