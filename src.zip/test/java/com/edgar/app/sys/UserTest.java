package com.edgar.app.sys;

import com.edgar.core.repository.BaseMapper;
import com.edgar.domain.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/dao.xml"})
@TransactionConfiguration(defaultRollback = true)
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
        TransactionalTestExecutionListener.class})
public class UserTest {

    @Autowired
    private BaseMapper<User, Integer> userMapper;

    @Transactional(propagation = Propagation.NEVER)
    @Test
    public void testInsert() {
        User user = new User();
        user.setUsername("admin");
        user.setPassword("admin");
        user.setSalt("-");
        user.setOrganization(1);
        user.setIsAdmin(true);
        user.setUserId(1);
        userMapper.insert(user);
    }
}
