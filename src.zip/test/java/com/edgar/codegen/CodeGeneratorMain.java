package com.edgar.codegen;

import com.mulampaka.spring.data.jdbc.codegen.CodeGenerator;
import org.junit.Test;

/**
 * Created by Administrator on 2015/6/9.
 */
public class CodeGeneratorMain {

    public static void main(String[] args) throws Exception {
        CodeGenerator generator = new CodeGenerator();
        generator.setPropertiesFile("src/test/resources/codegenerator.properties");
        generator.generate();
    }
}
