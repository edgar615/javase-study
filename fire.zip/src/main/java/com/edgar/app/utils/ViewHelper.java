package com.edgar.app.utils;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;

import java.util.Map;

/**
 * Created by edgar on 15-6-11.
 */
public class ViewHelper {

    private static final Map<String, Map<Object, Object>> DICTORY = Maps.newHashMap();

    static {
        /************************/
        /******** 申报职业 *******/
        /************************/
        Map<Object, Object> map = Maps.newHashMap();
        map.put(1, "灭火员");
        map.put(2, "消防抢险救援员");
        map.put(3, "防火员");
        map.put(4, "建（构）筑物消防员");
        map.put(5, "消防安全管理员");
        map.put(6, "消防设施维修检测工");
        map.put(7, "消防设施安装工");
        map.put(8, "消防产品质量检测员");
        map.put(9, "其他消防员");
        DICTORY.put("申报职业", map);

        /************************/
        /******** 申报级别 *******/
        /************************/
        map = Maps.newHashMap();
        map.put(1, "初级（国家职业资格五级）");
        map.put(2, "中级（国家职业资格四级）");
        map.put(3, "高级（国家职业资格三级）");
        map.put(4, "高级技师（国家职业资格一级）");
        DICTORY.put("申报级别", map);

        /************************/
        /******** 培训地点 *******/
        /************************/
        map = Maps.newHashMap();
        map.put(1, "武汉市");
        map.put(2, "襄樊市");
        map.put(3, "宜昌市");
        map.put(4, "荆门市");
        map.put(5, "十堰市");
        map.put(6, "黄石市");
        map.put(7, "荆州市");
        map.put(8, "鄂州市");
        map.put(9, "孝感市");
        map.put(10, "咸宁市");
        map.put(11, "黄冈市");
        map.put(12, "随州市");
        map.put(13, "恩施州");
        map.put(14, "汉江");
        DICTORY.put("培训地点", map);

        /************************/
        /******** 身份证件 *******/
        /************************/
        map = Maps.newHashMap();
        map.put(1, "居民身份证");
        map.put(2, "士兵证");
        map.put(3, "军官证");
        map.put(4, "警官证");
        map.put(5, "护照");
        map.put(6, "其他");
        DICTORY.put("身份证件", map);

        /************************/
        /******** 性别 *******/
        /************************/
        map = Maps.newHashMap();
        map.put(1, "男");
        map.put(2, "女");
        DICTORY.put("性别", map);

        /************************/
        /******** 文化程度 *******/
        /************************/
        map = Maps.newHashMap();
        map.put(1, "初中");
        map.put(2, "中等专业学校");
        map.put(3, "高中");
        map.put(4, "大学专科和专科学校");
        map.put(5, "大学本科");
        map.put(6, "本科以上");
        DICTORY.put("文化程度", map);

        /************************/
        /******** 政治面貌 *******/
        /************************/
        map = Maps.newHashMap();
        map.put(1, "中国共产党党员");
        map.put(2, "中国共青团团员");
        map.put(3, "民主党派人士");
        map.put(4, "无党派民主人士");
        DICTORY.put("政治面貌", map);
    }

    public static Object dictText(String type, Object code) {
        Map<Object, Object> map = DICTORY.get(type);
        if (map == null) {
            return null;
        }
        return map.get(code);
    }

    public static String dictOptions(String type, Object code) {
        Map<Object, Object> map = DICTORY.get(type);
        if (map == null) {
            return null;
        }
        StringBuilder source = new StringBuilder("<option value=\"\"></option>");
        for (Map.Entry<Object, Object> entry : map.entrySet()) {
            source.append("<option value=\"" + entry.getKey() + "\"");
            if (code != null && entry.getKey().toString().equals(code.toString())) {
                source.append(" selected");
            }
            source.append(">" + entry.getValue() + "</option>");
        }
        return source.toString();
    }
}
