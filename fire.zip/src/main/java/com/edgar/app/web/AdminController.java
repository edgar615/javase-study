package com.edgar.app.web;

import com.edgar.app.service.ApplicantService;
import com.edgar.app.service.CourseService;
import com.edgar.core.mvc.QueryParams;
import com.edgar.core.mvc.ToQueryParams;
import com.edgar.core.service.Pagination;
import com.edgar.domain.Applicant;
import com.edgar.domain.Course;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.Map;

/**
 * Created by edgar on 15-6-15.
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private ApplicantService applicantService;

    @Autowired
    private CourseService courseService;

    @RequestMapping("/applicants")
    public String applicants(@ToQueryParams QueryParams queryParams, HttpServletRequest request) {
        Pagination<Applicant> pagination = applicantService.pagination(queryParams.getValues(), queryParams.getPage(), queryParams.getPageSize());
        request.setAttribute("pagination", pagination);
        return "admin/applicants";
    }

    @RequestMapping("/courses")
    public String courses(@ToQueryParams QueryParams queryParams, HttpServletRequest request) {
        Pagination<Course> pagination = courseService.pagination(queryParams.getValues(), queryParams.getPage(), queryParams.getPageSize());
        request.setAttribute("pagination", pagination);
        return "admin/courses";
    }

    @RequestMapping("/deletecourse")
    public String deleteCourse(@RequestParam("courseId") int id) {
        courseService.deleteByPrimaryKey(id);
        return "redirect:/admin/courses";
    }

    @RequestMapping("/localadd")
    public String localadd() {
        return "admin/local_course_add";
    }
    @RequestMapping("/savelocal")
    public String savelocal(@RequestParam("file") CommonsMultipartFile file, Course course) {
        courseService.insert(course, file);
        return "redirect:/admin/courses";
    }
}
