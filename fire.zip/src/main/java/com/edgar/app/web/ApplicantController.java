package com.edgar.app.web;

import com.edgar.app.service.ApplicantService;
import com.edgar.core.service.BaseService;
import com.edgar.domain.Applicant;
import com.edgar.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * Created by edgar on 15-6-14.
 */
@Controller
@RequestMapping("/applicant")
public class ApplicantController {

    @Autowired
    private ApplicantService applicantService;

    @RequestMapping(value = "/profile", method = RequestMethod.GET)
    public String editProfile(HttpServletRequest request) {
        User user = (User) request.getSession().getAttribute("user");
        request.setAttribute("user", user);
        request.setAttribute("applicant", applicantService.fetchApplicantByUserId(user.getUserId()));
        return "/applicant/profile";
    }

    @RequestMapping(value = "/saveprofile", method = RequestMethod.POST)
    public String saveProfile(@Valid Applicant applicant, BindingResult result, HttpServletRequest request) {
        if (result.hasErrors()) {
            request.setAttribute("result", result);
            request.setAttribute("applicant", applicant);
            return "redirect:/applicant/profile";
        }
        applicantService.updateByPrimaryKey(applicant);
        return "redirect:/applicant/profile";
    }
}
