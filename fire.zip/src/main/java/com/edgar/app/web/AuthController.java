package com.edgar.app.web;

import com.edgar.app.service.AuthService;
import com.edgar.app.service.LoginCmd;
import com.edgar.app.service.RegisterCmd;
import com.edgar.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login() {
        // TODO 增加一个Token
        return "login";
    }

    @RequestMapping(value = "/login2", method = RequestMethod.POST)
    public String login(@Valid LoginCmd command, HttpSession session) {
        User user = authService.login(command);
        session.setAttribute("user", user);
        if (user.getIsAdmin()) {
            return "redirect:sys/applicant";
        }
        //　todo 保存到session中，后面修改
        return "redirect:/applicant/profile";
    }

    @RequestMapping(value = "/logout")
    public String logout(HttpSession session) {
        session.removeAttribute("user");
        return "login";
    }

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String register() {
        // TODO 增加一个Token
        return "register";
    }

    @RequestMapping(value = "/register2", method = RequestMethod.POST)
    public String register2(@Valid RegisterCmd cmd, BindingResult result, HttpServletRequest request) {
        if (result.hasErrors()) {
            request.setAttribute("result", result);
            request.setAttribute("cmd", cmd);
            return "register";
        }
        User user = authService.register(cmd);
        //　todo 保存到session中，后面修改
        request.getSession().setAttribute("user", user);
        return "redirect:/applicant/profile";
    }
}
