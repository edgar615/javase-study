package com.edgar.app.service;

import com.edgar.core.service.BaseService;
import com.edgar.core.service.Pagination;
import com.edgar.domain.Applicant;

import java.util.Map;

/**
 * Created by Administrator on 2015/6/16.
 */
public interface ApplicantService extends BaseService<Applicant, Integer> {
    Applicant fetchApplicantByUserId(int userId);

    Pagination<Applicant> pagination(Map<String, Object> params, int page, int pageSize);
}
