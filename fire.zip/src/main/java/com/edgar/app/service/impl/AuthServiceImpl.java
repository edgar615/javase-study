package com.edgar.app.service.impl;

import com.edgar.app.service.*;
import com.edgar.core.auth.PasswordService;
import com.edgar.domain.Applicant;
import com.edgar.domain.User;
import org.apache.shiro.authc.UnknownAccountException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * Created by edgar on 15-6-15.
 */
@Service
public class AuthServiceImpl implements AuthService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthServiceImpl.class);

    @Autowired
    private UserService userService;

    @Autowired
    private ApplicantService applicantService;

    @Autowired
    private PasswordService passwordService;

    @Override
    public User login(LoginCmd command) {
        User user = userService.fetchByUsername(command.getUsername());
        if (user == null) {
            LOGGER.warn("{}登录失败，用户名不存在", command.getUsername());
            throw new UnknownAccountException("用户名或密码错误");
        }
        String enctryPasword = passwordService.encryptPassword(command.getUsername(), command.getPassword(), user.getSalt());
        if (!enctryPasword.equals(user.getPassword())) {
            throw new UnknownAccountException("用户名或密码错误");
        }
        LOGGER.info("{}登录", user.getUsername());
        return user;
    }

    @Transactional
    @Override
    public User register(RegisterCmd command) {
        checkArgument(command.getPassword().equals(command.getPassword2()));
        User user = command.transferToUser();
        String salt = passwordService.saltGenerator();
        String password = passwordService.encryptPassword(user.getUsername(), user.getPassword(), salt);
        user.setSalt(salt);
        user.setPassword(password);
        userService.insert(user);

        Applicant applicant = command.transferToApplicant();
        applicant.setUserId(user.getUserId());
        applicant.setFullname("-");
        applicant.setPolitics(0);

        applicantService.insert(applicant);
        LOGGER.info("{}注册", user.getUsername());
        return user;
    }
}
