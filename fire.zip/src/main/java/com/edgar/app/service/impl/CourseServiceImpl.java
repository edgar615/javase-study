package com.edgar.app.service.impl;

import com.edgar.app.service.CourseService;
import com.edgar.core.repository.BaseMapper;
import com.edgar.core.repository.IDSeq;
import com.edgar.core.service.Pagination;
import com.edgar.core.service.PaginationCmd;
import com.edgar.core.service.PaginationCmdBuilder;
import com.edgar.core.service.PaginationService;
import com.edgar.core.service.impl.BaseServiceImpl;
import com.edgar.domain.Course;
import com.edgar.domain.CourseSum;
import com.edgar.repository.CourseMapper;
import com.edgar.repository.CourseSumMapper;
import com.google.common.base.Preconditions;
import org.apache.shiro.crypto.RandomNumberGenerator;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Map;

/**
 * Created by edgar on 15-6-11.
 */
@Service
public class CourseServiceImpl extends BaseServiceImpl<Course, Integer> implements CourseService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CourseServiceImpl.class);

    @Autowired
    private CourseMapper courseMapper;

    @Autowired
    private CourseSumMapper courseSumMapper;

    @Autowired
    private PaginationService paginationService;

    @Autowired
    private IDSeq idSeq;

    @Value("${file.upload}")
    private String fileUploadPath;

    @Value("${pdf2swf.path}")
    private String pdf2swfPath;

    @Override
    public BaseMapper<Course, Integer> getMapper() {
        return courseMapper;
    }

    @Transactional
    @Override
    public int insert(Course entity) {
        //更新courseSum
        CourseSum courseSum = updateSum(entity);
        if (entity.getId() == null || entity.getId() > 0) {
            entity.setId(idSeq.nextId());
        }
        entity.setCourseSumId(courseSum.getCourseSumId());
        return courseMapper.insert(entity);
    }

    @Transactional
    @Override
    public int deleteByPrimaryKey(Integer id) {
        Course course = selectByPrimaryKey(id);
        Preconditions.checkNotNull(course);
        courseSumMapper.deleteCourse(course);
        return super.deleteByPrimaryKey(id);
    }

    @Transactional
    @Override
    public void insert(Course course, CommonsMultipartFile file) {
        String path = saveFile(file);
        course.setCoursePath(path);
        insert(course);
    }

    private String saveFile(CommonsMultipartFile file) {
        String fileName = file.getOriginalFilename();
        String type = fileName.substring(fileName.lastIndexOf(".") + 1);
        File parentFile = new File(fileUploadPath + "/" + type);
        if (!parentFile.exists()) {
            parentFile.mkdir();
        }
        RandomNumberGenerator randomNumberGenerator = new SecureRandomNumberGenerator();
        String newFileName = randomNumberGenerator.nextBytes().toHex() + "." + type;
        String path = fileUploadPath + "/" + type + "/" + newFileName;

        File localFile = new File(path);
        try {
            file.transferTo(localFile);
        } catch (IOException e) {
            throw new RuntimeException("上传文件失败");
        }
        if ("pdf".equalsIgnoreCase(type)) {

        }
        //保存相对位置
        return newFileName;
    }

    private String pdf2swf(String path) {
        String newFilePath = path.substring(0, path.lastIndexOf(".")) + ".swf";
        String command = pdf2swfPath + " " + path + " -o " + newFilePath +  " -f -T 9 -t -s storeallcharacters";
        //执行cmd命令
//                C:\SWFTools\pdf2swf.exe Paper.pdf -o Paper.swf -f -T 9 -t -s storeallcharacters
        try {
            Runtime.getRuntime().exec("cmd /c " + command);
        } catch (IOException e) {
            throw new RuntimeException("转换pdf失败");
        }
        return path;
    }

    private CourseSum updateSum(Course entity) {
        CourseSum courseSum = courseSumMapper.fetchByType(entity.getOccupation(), entity.getApplicationLevel());
        if (courseSum == null) {
            try {
                courseSum = new CourseSum();
                courseSum.setCourseSumId(idSeq.nextId());
                courseSum.setApplicationLevel(entity.getApplicationLevel());
                courseSum.setOccupation(entity.getOccupation());
                courseSum.setCourseTime(entity.getCourseTime());
                courseSum.setCourseCount(1);
                courseSumMapper.insert(courseSum);
            } catch (DuplicateKeyException e) {
                LOGGER.warn("occupation:{},applicationLevel:{}的汇总表已经存在", entity.getOccupation(), entity.getApplicationLevel());
                courseSumMapper.addCourse(entity);
            }
        } else {
            courseSumMapper.addCourse(entity);
        }
        return courseSum;
    }

    @Override
    public Pagination<Course> pagination(Map<String, Object> params, int page, int pageSize) {
        PaginationCmd<Course> command = new PaginationCmdBuilder()
                .setParams(params)
                .setPage(page)
                .setPageSize(pageSize)
                .setCountStmt("com.edgar.repository.CourseMapper.count")
                .setSelectStmt("com.edgar.repository.CourseMapper.query").builder();
        return paginationService.fetchPage(command);
    }

}
