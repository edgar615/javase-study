package com.edgar.app.service;

import com.edgar.core.service.BaseService;
import com.edgar.core.service.Pagination;
import com.edgar.domain.Course;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.util.Map;

/**
 * Created by edgar on 15-6-11.
 */
public interface CourseService extends BaseService<Course, Integer> {
    Pagination<Course> pagination(Map<String, Object> params, int page, int pageSize);


    void insert(Course course, CommonsMultipartFile file);
}
