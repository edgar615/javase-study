package com.edgar.app.service;

import com.edgar.core.command.Command;
import com.edgar.domain.Applicant;
import com.edgar.domain.User;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Created by edgar on 15-6-13.
 */
public class RegisterCmd implements Command {
    @NotEmpty
    @Size(max = 16)
    private String username;

    @NotEmpty
    @Size (max = 128)
    private String password;

    @NotEmpty
    @Size (max = 128)
    private String password2;

    @NotNull
    private int occupation;

    @NotNull
    private int applicationLevel;

    public User transferToUser() {
        User user = new User();
        user.setUsername(this.getUsername());
        user.setPassword(this.getPassword());
        return user;
    }

    public Applicant transferToApplicant() {
        Applicant applicant = new Applicant();
        applicant.setApplicationLevel(this.getApplicationLevel());
        applicant.setOccupation(this.getOccupation());
        return applicant;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword2() {
        return password2;
    }

    public void setPassword2(String password2) {
        this.password2 = password2;
    }

    public int getOccupation() {
        return occupation;
    }

    public void setOccupation(int occupation) {
        this.occupation = occupation;
    }

    public int getApplicationLevel() {
        return applicationLevel;
    }

    public void setApplicationLevel(int applicationLevel) {
        this.applicationLevel = applicationLevel;
    }
}
