package com.edgar.app.service.impl;

import com.edgar.app.service.UserService;
import com.edgar.core.repository.BaseMapper;
import com.edgar.core.repository.IDSeq;
import com.edgar.core.service.impl.BaseServiceImpl;
import com.edgar.domain.User;
import com.edgar.repository.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2015/6/16.
 */
@Service
public class UserServiceImpl extends BaseServiceImpl<User, Integer> implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private IDSeq idSeq;

    @Override
    public BaseMapper<User, Integer> getMapper() {
        return userMapper;
    }

    @Override
    public int insert(User entity) {
        if (entity.getId() == null || entity.getId() > 0) {
            entity.setId(idSeq.nextId());
        }
        return super.insert(entity);
    }

    @Override
    public User fetchByUsername(String username) {
        return userMapper.fetchByUsername(username);
    }
}
