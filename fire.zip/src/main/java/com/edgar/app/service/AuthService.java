package com.edgar.app.service;

import com.edgar.domain.User;

/**
 * Created by edgar on 15-6-15.
 */
public interface AuthService {

    User login(LoginCmd cmd);

    User register(RegisterCmd cmd);
}
