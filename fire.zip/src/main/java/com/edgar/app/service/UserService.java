package com.edgar.app.service;

import com.edgar.core.service.BaseService;
import com.edgar.domain.User;

/**
 * Created by Administrator on 2015/6/16.
 */
public interface UserService extends BaseService<User, Integer> {
    User fetchByUsername(String username);
}
