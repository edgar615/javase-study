package com.edgar.core.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

/**
 * Spring Bean的工具类.
 *
 * @author Edgar
 * @version 1.0
 */
@Service
public class ServiceLookupImpl implements ApplicationContextAware, ServiceLookup {

    private ApplicationContext applicationContext;

    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    /**
     * 根据Bean的名称查找Spring Bean
     *
     * @param beanName 名称
     * @param clazz    类型
     * @param <T>      泛型
     * @return Spring Bean
     */
    @Override
    public <T> T getBean(String beanName, Class<T> clazz) {
        return applicationContext.getBean(beanName, clazz);
    }

    /**
     * 根据Bean的类型查找Spring Bean
     *
     * @param clazz 类型
     * @param <T>   泛型
     * @return Spring Bean
     */
    @Override
    public <T> T getBean(Class<T> clazz) {
        return applicationContext.getBean(clazz);
    }

    /**
     * 根据Bean的名称查找Spring Bean
     *
     * @param name
     *
     * @return Spring Bean
     */
    @Override
    public <T> T getBean(String name) {
        return (T) applicationContext.getBean(name);
    }
}