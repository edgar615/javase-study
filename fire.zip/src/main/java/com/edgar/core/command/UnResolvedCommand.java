package com.edgar.core.command;

class UnResolvedCommand implements Command {

}
