package com.edgar.core.mvc;

import org.apache.commons.lang.StringUtils;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebArgumentResolver;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.Iterator;

/**
 * Created by Administrator on 2015/6/16.
 */
public class QueryParamsResolver implements WebArgumentResolver {
    private String prefix;

    @Override
    public Object resolveArgument(MethodParameter methodParameter, NativeWebRequest webRequest) throws Exception {
        Class<?> paramType = methodParameter.getParameterType();
        if (paramType == QueryParams.class) {
            Iterator<String> paramterNames = webRequest.getParameterNames();
            QueryParams queryParams = new QueryParams(prefix);
            while (paramterNames.hasNext()) {
                String paramName = (String) paramterNames.next();
                String value = webRequest.getParameter(paramName);
                paramName = substringAfter(paramName,
                        prefix);
                if (StringUtils.isBlank(paramName)) {
                    continue;
                }
                if (StringUtils.isBlank(value)) {
                    continue;
                }
                queryParams.put(paramName, value);
            }
            return queryParams;
        }
        return UNRESOLVED;
    }

    private String substringAfter(String str, String separator) {
        int pos = str.indexOf(separator);
        if (pos == -1) {
            return "";
        }
        return str.substring(pos + separator.length());
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }
}
