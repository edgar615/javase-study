package com.edgar.core.mvc;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;

/**
 * 将request.contextpath设到base中
 *
 * @author 张雨舟
 * @version 1.0
 */
public class LayoutInterceptor extends HandlerInterceptorAdapter {

    private String prefix;

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {
        //contextPah
        request.setAttribute("base", request.getContextPath());
        //查询参数
        Enumeration<String> paramterNames = request.getParameterNames();
        QueryParams queryParams = new QueryParams(prefix);
        while (paramterNames.hasMoreElements()) {
            String paramName = paramterNames.nextElement();
            String value = request.getParameter(paramName);
            if (paramName.startsWith(prefix)) {
                paramName = substringAfter(paramName,
                        prefix);
                queryParams.put(paramName, value);
            }
        }
        request.setAttribute("params", queryParams);
        return super.preHandle(request, response, handler);
    }

    private static String substringAfter(String str, String separator) {
        int pos = str.indexOf(separator);
        if (pos == -1) {
            return "";
        }
        return str.substring(pos + separator.length());
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }
}