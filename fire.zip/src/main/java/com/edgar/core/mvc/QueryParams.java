package com.edgar.core.mvc;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.google.common.base.CharMatcher;
import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import org.apache.commons.lang.StringUtils;

public class QueryParams {

    private static final String PAGE = "page";
    private static final String PAGE_SIZE = "pageSize";

    private String prefix;

    private int page = 1;

    private int pageSize = 1;

    private Names names = new Names();

    private Map<String, Object> values = Maps.newHashMap();

    public QueryParams() {
    }

    public QueryParams(String prefix) {
        this.prefix = prefix;
    }

    public boolean isEmpty() {
        return values.isEmpty();
    }

    public void put(String name, Object value) {
        Preconditions.checkNotNull(value);
        Preconditions.checkNotNull(name);
        if (name.equals(PAGE) && !Strings.isNullOrEmpty(value.toString())) {
            page = Integer.parseInt(value.toString());
        }
        if (name.equals(PAGE_SIZE) && !Strings.isNullOrEmpty(value.toString())) {
            pageSize = Integer.parseInt(value.toString());
        }
        values.put(name, value);
    }

    public Names getNames() {
        return names;
    }

    public Map<String, Object> getValues() {
        return Collections.unmodifiableMap(values);
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
        values.put(PAGE, page);
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
        values.put(PAGE_SIZE, pageSize);
    }

    public class Names {
        public String get(String name) {
            if (StringUtils.isBlank(prefix)) {
                return name;
            }
            return prefix + name;
        }
    }

}