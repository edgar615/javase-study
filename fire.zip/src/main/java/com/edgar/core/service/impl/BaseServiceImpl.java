package com.edgar.core.service.impl;

import com.edgar.core.repository.BaseMapper;
import com.edgar.core.repository.IDSeq;
import com.edgar.core.service.*;
import com.edgar.core.repository.Persistable;
import com.edgar.core.spring.ServiceLookup;
import com.google.common.base.CaseFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sun.security.krb5.internal.PAData;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by edgar on 15-6-15.
 */
@Service
public abstract class BaseServiceImpl<T extends Persistable<ID>, ID> implements BaseService<T, ID> {

    private static final String OFFSET = "offset";
    private static final String LIMIT = "limit";
    private static final int MAX_RECORDS = 10000;

    @Autowired
    private ServiceLookup serviceLookup;

    @Autowired
    private IDSeq idSeq;

    @Autowired
    private BaseMapper<T, ID> mapper;

    @Autowired
    private PaginationService paginationService;

    public abstract BaseMapper<T, ID> getMapper();

    private BaseMapper getMapper(Class cls) {
        String mapperName = cls.getSimpleName() + "Mapper";
        mapperName = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_CAMEL, mapperName);
        return serviceLookup.getBean(mapperName);
    }

    @Override
    public T selectByPrimaryKey(ID id) {
        return getMapper().selectByPrimaryKey(id);
    }

    @Override
    public int insert(T entity) {
        return getMapper().insert(entity);
    }

    @Override
    public int updateByPrimaryKey(T entity) {
        return getMapper().updateByPrimaryKey(entity);
    }

    @Override
    public int deleteByPrimaryKey(ID id) {
        return getMapper().deleteByPrimaryKey(id);
    }

}
