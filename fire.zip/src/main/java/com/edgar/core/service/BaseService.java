package com.edgar.core.service;

import com.edgar.core.repository.Persistable;

/**
 * Created by edgar on 15-6-15.
 */
public interface BaseService<T extends Persistable<ID>, ID> {
    T selectByPrimaryKey(ID id);

    int insert(T entity);

    int updateByPrimaryKey(T entity);

    int deleteByPrimaryKey(ID id);

}
