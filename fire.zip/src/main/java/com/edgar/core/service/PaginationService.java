package com.edgar.core.service;

import java.util.Map;

/**
 * Created by Administrator on 2015/6/16.
 */
public interface PaginationService {
    <T> Pagination<T> fetchPage(PaginationCmd<T> command);
}
