package com.edgar.core.service;

import java.util.Map;

public class PaginationCmdBuilder {
    private Map<String, Object> params;
    private int page;
    private int pageSize;
    private String countStmt;
    private String selectStmt;

    public PaginationCmdBuilder setParams(Map<String, Object> params) {
        this.params = params;
        return this;
    }

    public PaginationCmdBuilder setPage(int page) {
        this.page = page;
        return this;
    }

    public PaginationCmdBuilder setPageSize(int pageSize) {
        this.pageSize = pageSize;
        return this;
    }

    public PaginationCmdBuilder setCountStmt(String countStmt) {
        this.countStmt = countStmt;
        return this;
    }

    public PaginationCmdBuilder setSelectStmt(String selectStmt) {
        this.selectStmt = selectStmt;
        return this;
    }

    public PaginationCmd builder() {
        return new PaginationCmd(params, page, pageSize, countStmt, selectStmt);
    }
}