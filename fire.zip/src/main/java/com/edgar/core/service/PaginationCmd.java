package com.edgar.core.service;

import com.edgar.core.command.Command;

import java.util.Map;

/**
 * Created by Administrator on 2015/6/16.
 */
public class PaginationCmd<T> implements Command {
    private Map<String, Object> params;
    private int page;
    private int pageSize;
    private String countStmt;
    private String selectStmt;

    PaginationCmd(Map<String, Object> params, int page, int pageSize, String countStmt, String selectStmt) {
        this.params = params;
        this.page = page;
        this.pageSize = pageSize;
        this.countStmt = countStmt;
        this.selectStmt = selectStmt;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public int getPage() {
        return page;
    }

    public int getPageSize() {
        return pageSize;
    }

    public String getCountStmt() {
        return countStmt;
    }

    public String getSelectStmt() {
        return selectStmt;
    }
}
