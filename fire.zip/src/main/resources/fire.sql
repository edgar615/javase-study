/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/6/11 18:54:05                           */
/*==============================================================*/


drop table if exists applicant;

drop table if exists certificate;

drop table if exists course;

drop table if exists course_sum;

drop table if exists examination_application;

drop table if exists examination_result;

drop table if exists role;

drop table if exists study_history;

drop table if exists study_history_sum;

drop table if exists user;

drop table if exists sequence;
create table `sequence` (
  id bigint(11) not null auto_increment,
  stub char(1) not null,
  primary key (id),
  unique key stub (stub)
) engine=myisam auto_increment=1 default charset=utf8;

/*==============================================================*/
/* Table: applicant                                             */
/*==============================================================*/
create table applicant
(
   applicant_id         int not null,
   user_id              int not null,
   fullname             varchar(8) not null default '-',
   gender               smallint not null default 1,
   phone                varchar(15) not null default '-',
   identity_type        smallint not null default 1,
   identity_no          varchar(18) not null default '-',
   nation               varchar(10) not null default '1',
   native_place         varchar(10) not null default '-',
   degree               smallint not null default 1,
   politics             smallint not null default '0',
   company              varchar(32) not null default '-',
   seniority            smallint not null default 0,
   photo_path           varchar(32) not null default '-',
   study_addr           smallint not null default 1,
   occupation           smallint not null default 1,
   application_level    smallint not null default 1,
   primary key (applicant_id)
);

alter table applicant comment '证件类型：1-居民身份证、2-士兵证、3-军官证、4-警官证、5-护照、6其他
性别：1-男、2-女
                              -&';

/*==============================================================*/
/* Table: certificate                                           */
/*==============================================================*/
create table certificate
(
   certificate_id       int not null,
   applicant_id         int,
   certificate_no       varchar(18) not null default '-',
   certificate_time     bigint not null default 0,
   certificate_dept     smallint not null,
   fullname             varchar(8) default '',
   gender               smallint default 1,
   identity_type        smallint default 1,
   identity_no          varchar(18) default '-',
   primary key (certificate_id)
);

alter table certificate comment '鉴定部门：1-湖北省消防总队职业技能鉴定站';

/*==============================================================*/
/* Table: course                                                */
/*==============================================================*/
create table course
(
   course_id            int not null,
   course_sum_id        int,
   course_name          varchar(20) not null default '-',
   description          varchar(140) not null default '-',
   course_time          smallint not null default 0,
   course_type          smallint default 1,
   course_path          varchar(64),
   occupation           smallint default 1,
   application_level    smallint default 1,
   primary key (course_id)
);

alter table course comment '课程类型：1-视频、2-文档
课时：单位是分钟';

/*==============================================================*/
/* Table: course_sum                                            */
/*==============================================================*/
create table course_sum
(
   course_sum_id        int not null,
   occupation           smallint not null default 1,
   application_level    smallint not null default 1,
   course_time          smallint not null default 0,
   course_count          smallint not null default 0,
   primary key (course_sum_id)
);

/*==============================================================*/
/* Table: examination_application                               */
/*==============================================================*/
create table examination_application
(
   examination_application_id int not null,
   applicant_id         int,
   apply_time           bigint not null default 0,
   status               smallint not null default 1,
   occupation           smallint not null default 1,
   application_level    smallint not null default 1,
   fullname             varchar(8) default '',
   gender               smallint default 1,
   identity_type        smallint default 1,
   identity_no          varchar(18) default '-',
   approval_opinion     varchar(140),
   approval_time        bigint,
   primary key (examination_application_id)
);

alter table examination_application comment '状态：1-待审批、2-驳回、3-审批通过';

/*==============================================================*/
/* Table: examination_result                                    */
/*==============================================================*/
create table examination_result
(
   examination_id       int not null,
   applicant_id         int,
   examination_type     smallint not null default 1,
   examination_cat      smallint not null default 1,
   examination_certificate_no bigint not null,
   theroy_score         numeric(3,2) not null default 0.0,
   theroy_grade         smallint not null default 1,
   handle_score         numeric(3,2) not null default 0.0,
   handle_grade         smallint not null default 1,
   grade                smallint not null default 1,
   examination_no       varchar(10) not null default '-',
   grade_time           timestamp not null default CURRENT_TIMESTAMP,
   fullname             varchar(8) default '',
   gender               smallint default 1,
   identity_type        smallint default 1,
   identity_no          varchar(18) default '-',
   primary key (examination_id)
);

alter table examination_result comment '考试类型：
考试类别：
理论考试情况：1-合格、2-不合格
实操考试情况：1-合格、';

/*==============================================================*/
/* Table: role                                                  */
/*==============================================================*/
create table role
(
   role_id              int not null,
   role_name            varchar(10) not null default '-',
   primary key (role_id)
);

/*==============================================================*/
/* Table: study_history                                         */
/*==============================================================*/
create table study_history
(
   study_history_id     int not null,
   applicant_id         int,
   study_history_sum_id int,
   course_id            int,
   study_time           smallint not null default 0,
   status               smallint not null default 1,
   course_name          varchar(20) default '-',
   course_type          smallint default 1,
   description          varchar(140) default '-',
   course_time          smallint default 0,
   occupation           smallint default 1,
   application_level    smallint default 1,
   fullname             varchar(8) default '',
   gender               smallint default 1,
   identity_type        smallint default 1,
   identity_no          varchar(18) default '-',
   primary key (study_history_id)
);

alter table study_history comment '状态：1-未学完、2-学完';

/*==============================================================*/
/* Table: study_history_sum                                     */
/*==============================================================*/
create table study_history_sum
(
   study_history_sum_id int not null,
   applicant_id         int,
   course_sum_id        int,
   study_time           smallint default 0,
   course_time          smallint default 0,
   status               smallint default 1,
   occupation           smallint default 1,
   application_level    smallint default 1,
   fullname             varchar(8) default '',
   gender               smallint default 1,
   identity_type        smallint default 1,
   identity_no          varchar(18) default '-',
   primary key (study_history_sum_id)
);

alter table study_history_sum comment '状态：1-未学完、2-学完';

/*==============================================================*/
/* Table: user                                                  */
/*==============================================================*/
create table user
(
   user_id              int not null,
   role_id              int,
   username             varchar(16) not null,
   password             char(128) not null,
   salt                 char(128) not null,
   organization         smallint not null default 1,
   is_admin             bool not null default false,
   primary key (user_id)
);

create unique index u_type on course_sum(occupation, application_level);