var Validate = function () {

    /***********
     (1)、required:true               必输字段
     (2)、remote:"remote-valid.jsp"   使用ajax方法调用remote-valid.jsp验证输入值
     (3)、email:true                  必须输入正确格式的电子邮件
     (4)、url:true                    必须输入正确格式的网址
     (5)、date:true                   必须输入正确格式的日期，日期校验ie6出错，慎用
     (6)、dateISO:true                必须输入正确格式的日期(ISO)，例如：2009-06-23，1998/01/22 只验证格式，不验证有效性
     (7)、number:true                 必须输入合法的数字(负数，小数)
     (8)、digits:true                 必须输入整数
     (9)、creditcard:true             必须输入合法的信用卡号
     (10)、equalTo:"#password"        输入值必须和#password相同
     (11)、accept:                    输入拥有合法后缀名的字符串（上传文件的后缀）
     (12)、maxlength:5                输入长度最多是5的字符串(汉字算一个字符)
     (13)、minlength:10               输入长度最小是10的字符串(汉字算一个字符)
     (14)、rangelength:[5,10]         输入长度必须介于 5 和 10 之间的字符串")(汉字算一个字符)
     (15)、range:[5,10]               输入值必须介于 5 和 10 之间
     (16)、max:5                      输入值不能大于5
     (17)、min:10                     输入值不能小于10
     */
    var runSetDefaultValidation = function () {
        $.validator.addMethod("notEqualTo", function (value, element, params) {
            return value != $(params).val();
        }, "请输入一个不同的值");
        $.validator.addMethod("letterNumberUnderline", function (value, element, params) {
            return /^[a-zA-z]\w*$/.test(value);
        }, "字母、数字、下划线组成，字母开头");

        $.validator.setDefaults({
            errorElement: "span", // contain the error msg in a small tag
            errorClass: 'help-block',
            errorPlacement: function (error, element) { // render error placement for each input type
                if (element.attr("type") == "radio" || element.attr("type") == "checkbox") { // for chosen elements, need to insert the error after the chosen container
                    error.insertAfter($(element).closest('.form-group').children('div').children().last());
                } else if (element.attr("name") == "card_expiry_mm" || element.attr("name") == "card_expiry_yyyy") {
                    error.appendTo($(element).closest('.form-group').children('div'));
                } else {
                    error.insertAfter(element);
                    // for other inputs, just perform default behavior
                }
            },
            ignore: ':hidden',
            highlight: function (element) {
                $(element).closest('.help-block').removeClass('valid');
                // display OK icon
                $(element).closest('.form-group').removeClass('has-success').addClass('has-error').find('.symbol').removeClass('ok').addClass('required');
                // add the Bootstrap error class to the control group
            },
            unhighlight: function (element) { // revert the change done by hightlight
                $(element).closest('.form-group').removeClass('has-error');
                // set error class to the control group
            },
            success: function (label, element) {
                label.addClass('help-block valid');
                // mark the current input as valid and display OK icon
                $(element).closest('.form-group').removeClass('has-error');
            },
            highlight: function (element) {
                $(element).closest('.help-block').removeClass('valid');
                // display OK icon
                $(element).closest('.form-group').addClass('has-error');
                // add the Bootstrap error class to the control group
            },
            unhighlight: function (element) { // revert the change done by hightlight
                $(element).closest('.form-group').removeClass('has-error');
                // set error class to the control group
            }
        });
    };
    var runLoginValidator = function () {
        var form = $('#login-form');
        var errorHandler = $('.errorHandler', form);
        form.validate({
            rules: {
                username: {
                    required: true
                },
                password: {
                    required: true
                }
            },
            submitHandler: function (form) {
                errorHandler.hide();
                form.submit();
            },
            invalidHandler: function (event, validator) { //display error alert on form submit
                errorHandler.show();
            },
            ignore: []
        });
    };
    var runRegisterValidator = function () {
        var form = $('#register-form');
        var errorHandler = $('.errorHandler', form);
        form.validate({
            rules: {
                username: {
                    required: true,
                    letterNumberUnderline : true,
                    rangelength: [3, 10]
                },
                password: {
                    required: true,
                    rangelength: [6, 16]
                },
                password2: {
                    required: true,
                    equalTo: "#password"
                },
                occupation: {
                    required: true
                },
                applicationLevel: {
                    required: true
                }
            },
            messages: {
                password2: {
                    equalTo: '两次输入的密码不同'
                }
            },
            submitHandler: function (form) {
                errorHandler.hide();
                form.submit();
            },
            invalidHandler: function (event, validator) { //display error alert on form submit
                errorHandler.show();
            },
            ignore: []
        });
    };
    var runApplicantValidator = function () {
        var form = $('#form');
        var errorHandler = $('.errorHandler', form);
        form.validate({
            rules: {
                studyAddr: {
                    required: true
                },
                identityType: {
                    required: true
                },
                identityNo: {
                    required: true
                },
                fullname: {
                    required: true,
                    maxlength : 8
                },
                nation: {
                    required: true,
                    maxlength : 10

                },
                nativePlace: {
                    required: true,
                    maxlength : 10

                },
                gender: {
                    required: true
                },
                degree: {
                    required: true
                },
                politics: {
                    required: true
                },
                phone: {
                    required: true,
                    maxlength : 15
                },
                company: {
                    required: true,
                    maxlength : 32
                },
                seniority: {
                    required: true
                }
            },
            submitHandler: function (form) {
                errorHandler.hide();
                form.submit();
            },
            invalidHandler: function (event, validator) { //display error alert on form submit
                errorHandler.show();
            },
            ignore: []
        });
    };
    var runLocalAddValidator = function () {
        var form = $('#form');
        var errorHandler = $('.errorHandler', form);
        form.validate({
            rules: {
                courseName: {
                    required: true,
                    maxlength : 100
                },
                courseTime: {
                    required: true,
                    digits : true,
                    min : 0
                },
                occupation: {
                    required: true
                },
                applicationLevel: {
                    required: true
                }
            },
            submitHandler: function (form) {
                errorHandler.hide();
                form.submit();
            },
            invalidHandler: function (event, validator) { //display error alert on form submit
                errorHandler.show();
            },
            ignore: []
        });
    };
    return {
        //main function to initiate template pages
        login: function () {
            runSetDefaultValidation();
            runLoginValidator();
        },
        register: function () {
            runSetDefaultValidation();
            runRegisterValidator();
        },
        applicant: function () {
            runSetDefaultValidation();
            runApplicantValidator();
        },
        localAdd : function() {
            runSetDefaultValidation();
            runLocalAddValidator();
        }
    };
}();